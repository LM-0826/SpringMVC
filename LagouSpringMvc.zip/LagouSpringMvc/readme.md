作业一mvc

xiaoA访问接口：

http://localhost:8080/user/requestA?username=xiaoA 

xiaoB访问接口：

http://localhost:8080/user/requestA?username=xiaoB

xiaoC访问接口：

http://localhost:8080/user/requestB?username=xiaoC

所有人都能方位接口

http://localhost:8080/user/requestC



作业二 sssPro

用户名和密码为:admin/admin
登录页：localhost:8080