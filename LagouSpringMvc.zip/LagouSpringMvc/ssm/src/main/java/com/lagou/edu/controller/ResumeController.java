package com.lagou.edu.controller;

import com.lagou.edu.pojo.Resume;
import com.lagou.edu.pojo.User;
import com.lagou.edu.service.ResumeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
@RequestMapping("/account")
public class ResumeController {

    /**
     * Spring容器和SpringMVC容器是有层次的（父子容器）
     * Spring容器：service对象+dao对象
     * SpringMVC容器：controller对象，，，，可以引用到Spring容器中的对象
     */


    @Autowired
    private ResumeService resumeService;

    @RequestMapping("/queryAll")
    @ResponseBody
    public List<Resume>  queryAll() throws Exception {
        return resumeService.queryResumeList();
    }

    @RequestMapping("/update")
    public ModelAndView update(@RequestBody Resume resume) throws Exception {
        Resume resume1 = this.resumeService.updateEntity(resume);
        ModelAndView modelAndView = new ModelAndView();
        if (resume1 != null) {
            List<Resume> resumes = resumeService.queryResumeList();
            modelAndView.addObject("resumeList", resumes);
            modelAndView.setViewName("resumeList");
        }
        return modelAndView;
    }

    @RequestMapping("/delete")
    public void update(Long id) throws Exception {
        this.resumeService.deleteEntity(id);
    }
}
