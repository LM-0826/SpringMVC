package com.lagou.edu.service;

import com.lagou.edu.pojo.Resume;
import com.lagou.edu.pojo.User;

import java.util.List;

public interface ResumeService {
    List<Resume> queryResumeList() throws Exception;

    Resume updateEntity(Resume resume);

    void deleteEntity(Long id);
}
