package com.lagou.demo.controller;


import com.lagou.demo.service.UserService;
import com.lagou.edu.mvcframework.annotations.LagouAutowired;
import com.lagou.edu.mvcframework.annotations.LagouController;
import com.lagou.edu.mvcframework.annotations.LagouRequestMapping;
import com.lagou.edu.mvcframework.annotations.LagouSecurity;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@LagouController
@LagouRequestMapping("/user")
public class UserController {

	@LagouAutowired
	private UserService userService;


	@LagouSecurity({"xiaoA","xiaoB"})
	@LagouRequestMapping("/requestA")
	public void requestA(HttpServletRequest request, HttpServletResponse response, String username){
		String str = userService.requestA(username);
		try {
			response.getWriter().write(str + username);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@LagouSecurity({"xiaoC"})
	@LagouRequestMapping("/requestB")
	public void requestB(HttpServletRequest request, HttpServletResponse response,String username){
		String str = userService.requestB(username);
		try {
			response.getWriter().write(str + username);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@LagouRequestMapping("/requestC")
	public void requestC(HttpServletRequest request, HttpServletResponse response,String username){
		String str = userService.requestC(username);
		try {
			response.getWriter().write(str);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
