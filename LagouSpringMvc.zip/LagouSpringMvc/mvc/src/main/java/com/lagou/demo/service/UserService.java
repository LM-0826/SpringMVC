package com.lagou.demo.service;

public interface UserService {

	String requestA(String userName);

	String requestB(String userName);

	String requestC(String userName);
}
