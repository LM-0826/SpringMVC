package com.lagou.demo.service.impl;

import com.lagou.demo.service.UserService;
import com.lagou.edu.mvcframework.annotations.LagouService;

@LagouService
public class UserServiceImpl implements UserService{
	@Override
	public String requestA(String userName) {
		String result = userName + "访问A成功请继续" ;
		return result;
	}

	@Override
	public String requestB(String userName) {
		String result = userName + "访问B成功请继续" ;
		return result;
	}

	@Override
	public String requestC(String userName) {
		String result = "访问C成功请继续" ;
		return result;
	}
}
